import org.junit.*;

/**
 * The test class MyHashMapTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AronsonHashMapTest extends junit.framework.TestCase
{
    private MyHashMap myHashMa1;


    /**
     * Default constructor for test class MyHashMapTest
     */
    public AronsonHashMapTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        myHashMa1 = new MyHashMap(10);
        
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }
    
    @Test
    public void testPut()
    {
        myHashMa1 = new MyHashMap(10);
        int count = 1121;
        for(int i=0; i<10; i++){
            assertTrue("Should not contain the key now", !myHashMa1.containsKey(""+count));
            assertNull("Putting an element with a new key should return null", myHashMa1.put(""+count, count));
            assertTrue("Should contain the key now", myHashMa1.containsKey(""+count));
            assertEquals("Size should be increasing by one", i+1, myHashMa1.size());
            count += 127;
        }

        assertEquals("Putting an element with an existing key should return the old value", 1121, myHashMa1.put("1121",1122));
        myHashMa1.put("1121", 1121);
        assertEquals("Size should still be 10", 10, myHashMa1.size());
    }
    
    @Test
    public void testSize()
    {
        testPut();
        assertEquals("Put 10 elements (one of them a replacement)", 10, myHashMa1.size());
        myHashMa1.remove("1121");
        assertEquals("Put 10 elements and removed 1", 9, myHashMa1.size());
        myHashMa1.remove("0000");
        assertEquals("Put 10 elements, removed 1, attempt to remove non-existent key", 9, myHashMa1.size());
        
    }
        
    @Test
    public void testGet(){
        testPut();
        int count = 1121;
        for(int i=0; i<10; i++){
            assertEquals(count, myHashMa1.get(""+count));
            count += 127;
        }
        
    }
    
    @Test
    public void testContainsKey(){
        
        testPut();
        int count = 1121;
        for(int i=0; i<10; i++){
            assertEquals(true, myHashMa1.containsKey(""+count));
            count += 127;
        }
        
        assertEquals(false, myHashMa1.containsKey("foo"));
    }
    
    @Test
    public void testKeySet() {
        java.util.Set s = myHashMa1.keySet();
        assertNotNull("An empty hashMap should return a valid keyset of size 0", s);
        assertEquals("An empty hash map should return a valid keyset of size 0",0, s.size());
        testPut();
        s = myHashMa1.keySet();
        assertNotNull(s);
        assertEquals("put 10 elements (one of them a replacement)",10, s.size());
        
        for(Object k : s)
            assertNotNull("found an invalid key in the keyset '"+k+"'",myHashMa1.get(k));
        

    }
    
    @Test
    public void testRemove(){
        testPut();
        int count = 1121;
        for(int i=0; i<10; i++){
            assertEquals("Remove should return the value just removed", count, myHashMa1.remove(""+count));
            count += 127;
        }
        assertNull("Removing non-existent key should return null", myHashMa1.remove("foo"));
        assertEquals("Everything removed.  Size should be 0",0,myHashMa1.size());
    }
        
    @Test
    public void testIncreaseCapacity()
    {
        testPut();
        int count = 343;
        for(int i=0; i<10; i++){
            assertNull("Putting an element with a new key should return null", myHashMa1.put("extra"+count, count));
            assertEquals("size should be increasing by 1", 11+i, myHashMa1.size());
            count += 415;
        }
        assertEquals("Put 10 elements size should be 20", 20, myHashMa1.size());
   
    }      
}

