import java.util.*;

/**
 * Create your own fixed-size HashMap.
 */
public class MyHashMap implements APMap
{
    /**
     * LOOK AT ME!!!! I'm an example of a private class.
     * I only exist in this of this class. Neat, huh?
     */
    private class KVPair{
        public Object key, value;
        public KVPair(Object k, Object v){
            key = k;
            value = v;
        }
    }

    private int size; // how many entries in the map  
    private KVPair[] myMap;

    /**
     * constructor setting initial hash table capacity
     */
    public MyHashMap(int capacity){
        myMap = new KVPair[capacity];
        size = 0;
    }

    /**
     * returns the size of the map.  
     * You will need to keep the size up to date in other methods.
     */
    public int size() { return size; }

    /**
     * return true if the given key is in the hash table, false otherwise
     */
    public boolean containsKey(Object key){
        if(size==0)
        {
            return false;
        }
        for(int i=0;i<myMap.length;i++)
        {
            if(myMap[i]!=null&&myMap[i].key!=null)
            {
                if(myMap[i].key.equals(key))
                {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isFull()
    {
        for(int i=0;i<myMap.length;i++)
        {
            if(myMap[i]==null)         
            {
                return false;
            }
        }
        return true;
    }

    public Object rehash(Object key, Object value)
    {
        KVPair[] myMap2=new KVPair[myMap.length+1];
        for(int i=0;i<myMap.length;i++)
        {
            Object k=myMap[i].key;
            Object v=myMap[i].value;
            int hash=Math.abs(k.hashCode())%myMap2.length;
            if(myMap2[hash]==null)
            {
                myMap2[hash]=new KVPair(k,v);
            }
            else
            {
                while(myMap2[hash]!=null)
                {
                    hash++;
                    if(hash>=myMap2.length)
                    {
                        hash=0;
                    }
                }
                myMap2[hash]=new KVPair(k,v);
            }
        }
        int index=Math.abs(key.hashCode())%myMap2.length;
        if(myMap2[index]==null)
        {
            myMap2[index]=new KVPair(key,value);
            size++;
            myMap=myMap2;
            return null;
        }
        else
        {
            while(myMap2[index]!=null)         
            {
                index++;
                if(index>=myMap2.length)
                {
                    index=0;
                }
            }
            myMap2[index]=new KVPair(key,value);
            size++;
            myMap=myMap2;
            return null;
        }

    }

    /**
     * put key/value into hashTable using linear probing for resolving collisions  
     * NOTE: If there is no room, increase the size of the table
     *       and rehash everything.
     * HINT:  Come back to this once you have finished remove.  
     *        (It will add a new case!)
     */
    public Object put(Object key, Object value){
        int index=Math.abs(key.hashCode()%myMap.length);
        if(size==myMap.length&&!containsKey(key))
        {
            return rehash(key,value);
        }
        if(myMap[index]==null)
        {
            myMap[index]=new KVPair(key,value);
            size++;
            return null;
        }
        else if(key.equals(myMap[index].key))
        {
            Object obj=myMap[index].value;
            myMap[index]=new KVPair(key,value);
            return obj;
        }
        else
        {
            Object obj=myMap[index].value;
            while(myMap[index]!=null)
            {
                if(key.equals(myMap[index].key))
                {
                    Object o=myMap[index].value;
                    myMap[index]=new KVPair(key,value);
                    return o;
                }
                index++;
                if(index>=myMap.length)
                {
                    index=0;
                }
            }

        }
        myMap[index]=new KVPair(key,value);
        size++;
        return null;

    }

    /**
     *   return the value at the given key in the table,
     *      null if key cannot be found.
     */
    public Object get(Object key){
        int index=Math.abs(key.hashCode())%myMap.length;   
        if(index<myMap.length&&myMap[index]!=null&&myMap[index].key!=null&&myMap[index].value!=null)
        {
            if(myMap[index].key.equals(key))
            {
                return myMap[index].value;
            }
        }

        for(int i=0;i<myMap.length;i++)
        {
            if(myMap[i]!=null)
            {
                if(myMap[i].key!=null)
                {
                    if(myMap[i].key.equals(key))
                    {
                        return myMap[i].value;
                    }
                }
            }
        }

        // if(myMap[index].key.equals(key))
        // {
        // return myMap[index].value;
        // }
        // else
        // {

        return null;
    }

    /**
     * remove the given key's data from the table
     * WARNING:  You cannot just replace it with null. Think about what
     *           would happen to linear probing if you did.
     *           You need to put some placeholder here instead.
     *           Maybe something like new KVPair(null, null)
     *           Think hard about what is happening here...
     */
    public Object remove(Object key){
        int hashCode=Math.abs(key.hashCode())%myMap.length;
        if(!containsKey(key))
        {
            return null;
        }
        if(myMap[hashCode]!=null&&myMap[hashCode].key!=null&&myMap[hashCode].key.equals(key))
        {
            Object obj=myMap[hashCode].value;
            myMap[hashCode]=new KVPair(null,null);
            size--;
            return obj;
        }
        else
        {
            int count=hashCode+1;
            if(count==myMap.length)
            {
                count=0; 
            }
            while(count!=hashCode)
            {
                if(myMap[count]!=null&&myMap[count].key!=null&&myMap[count].key.equals(key))
                {
                    Object obj=myMap[count].value;
                    myMap[count]=new KVPair(null,null);
                    size--;
                    return obj;
                }
                count++;
                if(count==myMap.length)
                {
                    count=0;
                }
            }
        }
        return null;
    }

    /**
     * return a set of all the keys in the hash table
     */
    public Set keySet(){
        Set set=new HashSet();
        for(int i=0;i<myMap.length;i++)
        {
            if(myMap[i]!=null)
            {
                set.add(myMap[i].key);
            }
        }
        return set;
    }

    public String largestKey()
    {
        String ans="";
        int x=0;
        for(int i=0;i<myMap.length;i++)
        {
            if(myMap[i]!=null&&myMap[i].key!=null&&myMap[i].value!=null)
            {
                if(x<(Integer)myMap[i].value)
                {
                    x=(Integer)myMap[i].value;
                    ans=(String)myMap[i].key;
                }
            }
        }
        return ans;
    }

}
