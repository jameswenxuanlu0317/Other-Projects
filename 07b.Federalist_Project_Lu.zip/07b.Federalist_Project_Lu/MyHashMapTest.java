import org.junit.*;

/**
 * The test class MyHashMapTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class MyHashMapTest extends junit.framework.TestCase
{
    private MyHashMap hm;

    /**
     * Default constructor for test class MyHashMapTest
     */
    public MyHashMapTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        hm = new MyHashMap(1);

    }

    @Test
    /**
     * 
     */
    public void testPut()
    {
        hm = new MyHashMap(1);
        assertNull(hm.put(1, 2));
        assertEquals(2, hm.put(1,3));
        assertEquals(1,hm.size());
        hm.put(2,1);
        assertEquals(2,hm.size());
    }
    @Test
    /**
     * 
     */
    public void testGet()
    {
        hm = new MyHashMap(1);
        hm.put(1,2);
        assertEquals(2,hm.get(1));
    }
    @Test
    public void testKey()
    {
        hm = new MyHashMap(1);
        hm.put(1,2);
        assertTrue(hm.containsKey(1));
        assertFalse(hm.containsKey(2));
    }
    @Test
    public void testRemove()
    {
        hm=new MyHashMap(1);
        hm.put(1,2);
        assertEquals(2,hm.remove(1));
        assertNull(hm.remove(3));
    }
    

}
