import java.util.*;
import java.io.*;
public class FederalistPapers
{
    static public final String FILE_PREFIX = "federalist_";
    static public final String FILE_SUFFIX = ".txt";
    static public final int INITIAL_CAPACITY=100;
    String[] authors = {"Madison", "Hamilton", "Jay", "Shared", "Disputed"};
    public MyHashMap Madison=new MyHashMap(INITIAL_CAPACITY);
    public MyHashMap Hamilton=new MyHashMap(INITIAL_CAPACITY);
    public MyHashMap Jay=new MyHashMap(INITIAL_CAPACITY);
    public MyHashMap Shared=new MyHashMap(INITIAL_CAPACITY);
    public MyHashMap Disputed=new MyHashMap(INITIAL_CAPACITY);
    public MyHashMap All=new MyHashMap(INITIAL_CAPACITY);
    public TreeMap<String, Double> MadCommon=new TreeMap<String, Double>();
    public TreeMap<String, Double> HamCommon=new TreeMap<String, Double>();
    public TreeMap<String, Double> JayCommon=new TreeMap<String, Double>();
    public TreeMap<String, Double> DisCommon=new TreeMap<String, Double>();    

    /* Works are in the same order as the authors */
    int[][] works = {
            {10, 14, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48},
            {1, 6, 7, 8, 9, 11, 12, 13, 15, 16, 17, 21, 22, 23, 24,
                25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 59, 60,
                61, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
                78, 79, 80, 81, 82, 83, 84, 85},
            {2, 3, 4, 5},
            {18, 19, 20},
            {49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 62, 63, 64}
        };
    /**
     * a helper method of storing words in the document with frequency
     * returning number of words in total.
     */
    public int storeFreqHelper2(String infile, MyHashMap hm)
    {
        int numWords=0;
        try
        {
            FileReader reader = new FileReader(new File(infile));
            Scanner scan=new Scanner(reader).useDelimiter("[ ,!?.]+");
            while(scan.hasNextLine())
            {
                String nextLine=scan.nextLine();
                nextLine=nextLine.replaceAll("\\p{Punct}", "");
                Scanner scan2=new Scanner(nextLine);
                while(scan2.hasNext())
                {
                    String word=scan2.next();
                    if(word.matches("[a-zA-Z]+"))
                    {
                        word=word.toLowerCase();
                    }
                    if(!hm.containsKey(word))
                    {
                        hm.put(word,1);
                        numWords++;
                    }
                    else
                    {
                        int val=(Integer)hm.get(word);
                        val++;
                        hm.put(word,val);
                        numWords++;
                    }
                }
                scan2.close();
            }
            scan.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Processing Files");
            System.out.println(e);
            e.printStackTrace(); 
        }
        return numWords;
    }

    /**
     * a helper method of storing words in the document with frequency
     */
    public void storeFreqHelper(String infile, MyHashMap hm)
    {
        int numWords=0;
        try
        {
            FileReader reader = new FileReader(new File(infile));
            Scanner scan=new Scanner(reader).useDelimiter("[ ,!?.]+");
            while(scan.hasNextLine())
            {
                String nextLine=scan.nextLine();
                nextLine=nextLine.replaceAll("\\p{Punct}", "");//get rid of all punctuations
                Scanner scan2=new Scanner(nextLine);
                while(scan2.hasNext())
                {
                    String word=scan2.next();
                    if(word.matches("[a-zA-Z]+"))
                    {
                        word=word.toLowerCase();//set everything to lowercase
                    }
                    if(!hm.containsKey(word))
                    {
                        hm.put(word,1);
                        numWords++;
                    }
                    else
                    {
                        int val=(Integer)hm.get(word);
                        val++;
                        hm.put(word,val);
                        numWords++;
                    }
                }
                scan2.close();
            }
            scan.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Processing Files");
            System.out.println(e);
            e.printStackTrace(); 
        }

    }

    /**
     * store frequency of three author documents into three different
     * hashmap
     */
    public void storeFreq()
    { 
        for(int i=0;i<=2;i++)
        {
            for(int j=0;j<works[i].length;j++)
            {
                if(i==0)
                {
                    String infile="data/"+FILE_PREFIX+works[i][j]+FILE_SUFFIX;
                    storeFreqHelper(infile,Madison);
                }
                else if(i==1)
                {
                    String infile="data/"+FILE_PREFIX+works[i][j]+FILE_SUFFIX;
                    storeFreqHelper(infile,Hamilton);
                }
                else if(i==2)
                {
                    String infile="data/"+FILE_PREFIX+works[i][j]+FILE_SUFFIX;
                    storeFreqHelper(infile,Jay);
                }
            }
        }

    }

    /**
     * get the average word length of the disputed file
     * using scanners to scan through
     */
    public double checkDisputed(String infile)
    {
        double ans=0.0;
        ArrayList<String> list=new ArrayList();       

        try
        {
            FileReader reader = new FileReader(new File(infile));
            Scanner scan=new Scanner(reader).useDelimiter("[ ,!?.]+");
            while(scan.hasNextLine())
            {                
                String nextLine=scan.nextLine();
                nextLine=nextLine.replaceAll("\\p{Punct}", "");
                Scanner scan2=new Scanner(nextLine);
                while(scan2.hasNext())
                {
                    String word=scan2.next();
                    list.add(word);
                    ans+=word.length();
                }
                scan2.close();
            }
            scan.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Processing Files");
            System.out.println(e);
            e.printStackTrace();
        }
        ans=ans/list.size();
        return ans;
    }

    /**
     * Step 3 on the instruction
     * check the differences between average word length of each
     * disputed work vs. each author
     * return the minimum of the three author as to be determined 
     * as the one that wrote the disputed work
     */
    public void stepThree()
    {
        storeFreq();
        double madison=getWordLength(Madison);
        double hamilton=getWordLength(Hamilton);
        double jay=getWordLength(Jay);
        for(int i=0;i<works[4].length;i++)
        {
            String file="data/"+FILE_PREFIX+works[4][i]+FILE_SUFFIX;
            double disputed=checkDisputed(file);
            double maddif=Math.abs(disputed-madison);
            double hamdif=Math.abs(disputed-hamilton);
            double jaydif=Math.abs(disputed-jay);
            double min=returnMin(maddif,hamdif,jaydif);
            if(min==jaydif)
            {
                System.out.println(file+" is the work of Jay");
            }
            else if(min==maddif)
            {
                System.out.println(file+" is the work of Madison");
            }
            else if(Math.min(maddif,hamdif)==hamdif)
            {
                System.out.println(file+" is the work of Hamilton");
            }
        }
    }

    /**
     * Get average word length for all words in a hashmap
     */
    public double getWordLength(MyHashMap hm)
    {
        double ans=0.0;
        int length=0;
        Set set=hm.keySet();
        Iterator<String> iter=set.iterator();
        while(iter.hasNext())
        {
            String str=iter.next();
            int times=(Integer)hm.get(str);
            ans+=(str.length())*times;
            length+=times;
        }
        ans=ans/length;
        return ans;
    }

    /**
     * print out the average word length of each author
     */
    public void printWordLength()
    { 
        double madisonLength=getWordLength(Madison);
        double hamiltonLength=getWordLength(Hamilton);
        double jayLength=getWordLength(Jay);
        System.out.println("Madison's average word length is: "+madisonLength);
        System.out.println("Hamilton's average word length is: "+hamiltonLength);
        System.out.println("Jay's average word length is: "+jayLength);
    }

    /**
     * step 2 on the instruction sheet
     * calculate and print the average word length for each author
     */
    public void step2()
    {
        storeFreq();
        printWordLength();
    }

    /**
     * get average sentence length of a file
     * check for ending-sentence punctuations ".?!" to determine when
     * the sentence end
     * return the average number of words in a sentence in each file
     */
    public double sentLength(String infile)
    {        
        double ans=0.0;
        int numS=0;
        try
        {
            FileReader reader = new FileReader(new File(infile));
            Scanner scan=new Scanner(reader).useDelimiter("[,]+");;
            while(scan.hasNextLine())
            {
                String nextLine=scan.nextLine();
                Scanner scan2=new Scanner(nextLine);
                while(scan2.hasNext())
                {
                    String word=scan2.next();
                    if(word.contains(".")||word.contains("?")||word.contains("!"))
                    {
                        numS++;
                    }
                    else 
                    {
                        ans++;
                    }
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Error Processing Files");
            System.out.println(e);
            e.printStackTrace();
        }
        ans=ans/numS;
        return ans;
    }

    /**
     * return the average number of words in the arraylist
     */
    public double getAverage(ArrayList list)
    {
        double ans=0.0;
        for(int i=0;i<list.size();i++)
        {            
            ans+=(double)list.get(i);
        }
        ans=ans/list.size();
        return ans;
    } 

    /**
     * return the minumum value of three doubles
     */
    public double returnMin(double a, double b, double c)
    {
        double smallest;
        if (a <= b && a <= c) {
            smallest = a;
        } else if (b <= c && b <= a) {
            smallest = b;
        } else {
            smallest = c;
        }
        return smallest;       
    }

    /**
     * step 4 and 5 on the instruction sheet
     * calculate and print the average sentence length of each author
     * adding sentence lengths to each created arraylist storing doubles
     * get the average value of sentence length using helper method
     * compare each author's average sentence length with each disputed works
     * then determine who wrote the disputed work
     */
    public void step4and5()
    {
        ArrayList<Double> madlist=new ArrayList();
        ArrayList<Double> hamlist=new ArrayList();
        ArrayList<Double> jaylist=new ArrayList();   
        ArrayList<Double> disputed=new ArrayList();
        for(int i=0;i<3;i++)
        {
            for(int k=0;k<works[i].length;k++)
            {
                String file="data/"+FILE_PREFIX+works[i][k]+FILE_SUFFIX;
                double temp=sentLength(file);
                if(i==0)
                {
                    madlist.add(temp);
                }
                else if(i==1)
                {
                    hamlist.add(temp);
                }
                else if(i==2)
                {
                    jaylist.add(temp);
                }
            }

        }
        double madLength=getAverage(madlist);
        double hamLength=getAverage(hamlist);
        double jayLength=getAverage(jaylist);
        System.out.println("Madison's average sentence length is: "+madLength);
        System.out.println("Hamilton's average sentence length is: "+hamLength);
        System.out.println("Jay's average sentence length is: "+jayLength);
        for(int i=0;i<works[4].length;i++)
        {
            String file="data/"+FILE_PREFIX+works[4][i]+FILE_SUFFIX;
            disputed.add(sentLength(file));
            double disLength=getAverage(disputed);
            double maddif=Math.abs(disLength-madLength);
            double hamdif=Math.abs(disLength-hamLength);
            double jaydif=Math.abs(disLength-jayLength);
            double min=returnMin(maddif,hamdif,jaydif);
            if(min==jaydif)
            {
                System.out.println(file+" is the work of Jay");
            }
            else if(min==maddif)
            {
                System.out.println(file+" is the work of Madison");
            }
            else if(Math.min(maddif,hamdif)==hamdif)
            {
                System.out.println(file+" is the work of Hamilton");
            }
        }
    }

    /**
     * get the total number of words in the hashmap
     * return double because it will be easier to calculate
     */
    public double getTotal(MyHashMap hm)
    {
        double ans=0.0;
        Set set=hm.keySet();
        Iterator<String>iter=set.iterator();
        while(iter.hasNext())
        {
            String key=iter.next();
            int val=(Integer)hm.get(key);
            ans+=val;
        }
        return ans;
    }

    /**
     * get top 20 words in the hashmap
     * store top 20 words with percentage into each author's treemap
     */
    public void top20(MyHashMap hm, String author)
    {
        MyHashMap ans=hm;
        double total=getTotal(ans);
        for(int i=0;i<20;i++)    
        {
            String key=ans.largestKey();
            int val=(Integer)ans.get(key);
            double ratio=val/total;
            double percent=ratio*100;
            if(!author.equals("Disputed work"))
            {
                System.out.println(author+" common word: "+"\""+key+"\""+" is "+percent+"%");
            }
            ans.remove(key);
            if(author.equals("Madison"))
            {
                MadCommon.put(key, percent);
            }
            else if(author.equals("Hamilton"))
            {
                HamCommon.put(key, percent);
            }
            else if(author.equals("Jay"))
            {
                JayCommon.put(key, percent);
            }
            else if(author.equals("Disputed work"))
            {
                DisCommon.put(key, percent);
            }
        }

    }

    /**
     * step 6 and 7 on the instruction sheet
     * calculate and print the top 20 most common words for each author
     * with percentages
     * compare with disputed works and decide who wrote each one
     * compare number of words in common first
     * if tied, compare percentages
     */
    public void step6and7()
    {
        storeFreq();
        top20(Madison, "Madison");
        System.out.println();
        top20(Hamilton, "Hamilson");
        System.out.println();
        top20(Jay, "Jay");
        for(int i=0;i<works[4].length;i++)
        {
            String infile="data/"+FILE_PREFIX+works[4][i]+FILE_SUFFIX;
            storeFreqHelper(infile,Disputed);
            top20(Disputed, "Disputed work");
            int compareMad=compareCommon(MadCommon,DisCommon);
            int compareHam=compareCommon(HamCommon,DisCommon);
            int compareJay=compareCommon(JayCommon,DisCommon);
            int ans=findMax(compareMad,compareHam,compareJay);
            if(ans!=0)
            {
                if(ans==compareMad)
                {
                    System.out.println("Madison wrote "+infile);
                }
                else if(ans==compareHam)
                {
                    System.out.println("Hamilton wrote "+infile);
                }
                else if(ans==compareJay)
                {
                    System.out.println("Jay wrote "+infile);
                }
            }
            else
            {
                if(compareMad==compareHam&&compareMad>compareJay)
                {
                    double MadPer=comparePercent(MadCommon,DisCommon);
                    double HamPer=comparePercent(HamCommon,DisCommon);
                    if(MadPer>HamPer)
                    {
                        System.out.println("Hamilton wrote "+infile);
                    }
                    else if(HamPer>MadPer)
                    {
                        System.out.println("Madison wrote "+infile);
                    }
                    else
                    {
                        System.out.println("Either Hamilton or Madison wrote "+infile);
                    }
                }
                else if(compareMad==compareJay&&compareMad>compareHam)
                {
                    double MadPer=comparePercent(MadCommon,DisCommon);
                    double JayPer=comparePercent(JayCommon,DisCommon);
                    if(MadPer>JayPer)
                    {
                        System.out.println("Jay wrote "+infile);
                    }
                    else if(JayPer>MadPer)
                    {
                        System.out.println("Madison wrote "+infile);
                    }
                    else
                    {
                        System.out.println("Either Jay or Madison wrote "+infile);
                    }
                }
                else if(compareJay==compareHam&&compareJay>compareMad)
                {
                    double JayPer=comparePercent(JayCommon,DisCommon);
                    double HamPer=comparePercent(HamCommon,DisCommon);
                    if(JayPer>HamPer)
                    {
                        System.out.println("Hamilton wrote "+infile);
                    }
                    else if(HamPer>JayPer)
                    {
                        System.out.println("Jay wrote "+infile);
                    }
                    else
                    {
                        System.out.println("Either Hamilton or Jay wrote "+infile);
                    }
                }
            }
            Disputed=new MyHashMap(INITIAL_CAPACITY);
        }

    }

    /**
     * return maximum value of three integers
     * return 0 if there's a tie
     */
    public int findMax(int a, int b, int c)
    {
        if(a>b)
        {
            if(a>c)
            {
                return a;
            }
            else if(a<c)
            {
                return c;
            }
        }
        else if(a<b)
        {
            if(b>c)
            {
                return b;
            }
            else if(b<c)
            {
                return c;
            }
        }
        return 0;
    }

    /**
     * compare the percentages of common words
     * return the total percent difference
     */
    public double comparePercent(TreeMap<String, Double> map1,TreeMap<String, Double> map2 )
    {
        double ans=0.0;
        Set set=map1.keySet();
        Iterator<String> iter=set.iterator();
        while(iter.hasNext())
        {
            String key=iter.next();
            if(map2.containsKey(key))
            {
                double percent1=map1.get(key);
                double percent2=map2.get(key);
                ans+=Math.abs(percent1-percent2);
            }
        }
        return ans;
    }

    /**
     * compare common words
     * if second map contains the key word, score +1
     * if the key word is at exact position of two treemap, score+2
     */
    public int compareCommon(TreeMap<String, Double> map1,TreeMap<String, Double> map2 )
    {
        int count=0;
        Set set=map1.entrySet();
        Set set2=map2.entrySet();
        Iterator<Map.Entry> iter=set.iterator();
        Iterator<Map.Entry> iter2=set2.iterator();
        while(iter.hasNext())
        {
            Map.Entry m1=iter.next();
            Map.Entry m2=iter2.next();
            String key1=(String)m1.getKey();
            String key2=(String)m2.getKey();
            if(key1.equals(key2))
            {
                count+=2;
            }
            if(map2.containsKey(key1))
            {
                count++;
            }
        }
        return count;

    }
    //stats
    /**
     * statistics of the project
     * 
     */
    public void stats()
    {        
        ss5();
    }

    

    /**
     * Making decisions based on chi squared values for each author
     * 
     */
    public void ss5()
    {
        for(int i=0;i<works[4].length;i++)
        {
            String file="data/"+FILE_PREFIX+works[4][i]+FILE_SUFFIX;
            double Madison=getChiSquare("Madison", file, 200);
            double Hamilton=getChiSquare("Hamilton", file, 200);
            double Jay=getChiSquare("Jay", file, 200);
            double min=returnMin(Madison, Hamilton, Jay);
            System.out.println("Chi Square Value for Madison is "+Madison);
            System.out.println("Chi Square Value for Hamilton is "+Hamilton);
            System.out.println("Chi Square Value for Jay is "+Jay); 
            System.out.println();
            if(min==Madison)
            {
                System.out.println(file+" is the work of Madison");
            }
            else if(min==Hamilton)
            {
                System.out.println(file+" is the work of Hamilton");
            }
            else if(min==Jay)
            {
                System.out.println(file+" is the work of Jay");
            }
            System.out.println();
        }
        
    }

   /**
    * Getting chi square values for given author and given infile for
    * N number of common words
    */
    public double getChiSquare(String author, String infile, int N)
    {
        double chi_square=0.0;
        double numAuthor=0.0;
        double numDisputed=0.0;
        double otherDisputed=0.0;
        MyHashMap hm=new MyHashMap(INITIAL_CAPACITY);
        MyHashMap Author=new MyHashMap(INITIAL_CAPACITY);
        MyHashMap Disputed=new MyHashMap(INITIAL_CAPACITY);
        MyHashMap Other=new MyHashMap(INITIAL_CAPACITY);
        numDisputed+=storeFreqHelper2(infile, hm);
        storeFreqHelper(infile,Disputed);
        for(int i=0;i<works.length;i++)
        {
            for(int j=0;j<works[i].length;j++)
            {
                String file="data/"+FILE_PREFIX+works[i][j]+FILE_SUFFIX;
                if(i==0&&author.equals("Madison"))
                {
                    numAuthor+=storeFreqHelper2(file,hm);
                    storeFreqHelper(file,Author);
                }
                if(i==1&&author.equals("Hamilton"))
                {
                    numAuthor+=storeFreqHelper2(file,hm);
                    storeFreqHelper(file,Author);
                }
                if(i==2&&author.equals("Jay"))
                {
                    numAuthor+=storeFreqHelper2(file,hm);
                    storeFreqHelper(file,Author);
                }

                if(i==4)
                {

                    if(!file.equals(infile))
                    {
                        otherDisputed+=storeFreqHelper2(file,hm);
                        storeFreqHelper(file,Other);
                    }
                }

            }
        }       
        ArrayList<String> all=new ArrayList<String>();
        MyHashMap ans=hm;
        double total=getTotal(ans);
        for(int i=0;i<N;i++)    
        {
            String key=ans.largestKey();
            int val=(Integer)ans.get(key);
            all.add(key);
            //System.out.println("common word: "+"\""+key+"\"");
            ans.remove(key);
        }
        double joint_words=numAuthor+numDisputed+otherDisputed;
        double author_share=numAuthor/joint_words;
        double disputed_share=numDisputed/joint_words;
        double other_disputed=otherDisputed/joint_words;

        double author_count=0.0;
        double disputed_count=0.0;
        double other_count=0.0;
        for(int i=0;i<all.size();i++)
        {
            String word=all.get(i);
            if(Author.containsKey(word))
            {
                author_count+=(Integer)Author.get(word);
            }
            if(Disputed.containsKey(word))
            {
                disputed_count+=(Integer)Disputed.get(word);
            }
            if(Other.containsKey(word))
            {
                other_count+=(Integer)Other.get(word);
            }
        }
        double expected_author=joint_words*author_share;
        double expected_disputed=joint_words*disputed_share;
        double expected_other=joint_words*other_disputed;
        System.out.println("We should expect "+expected_author+" words from "+author);
        System.out.println("We should expect "+expected_disputed+" words from disputed work");
        System.out.println("There are actually "+author_count+" words from "+author);
        System.out.println("There are actually "+disputed_count+" words from disputed work");
        chi_square+=((author_count/expected_author)*(author_count/expected_author)/(expected_author));
        chi_square+=((disputed_count/expected_disputed)*(author_count/expected_disputed)/(expected_disputed));
        chi_square+=((other_count/expected_other)*(author_count/expected_other)/(expected_other));
        System.out.println();
        return chi_square;
    }

    public static void main(String args[]) {
    }
}
