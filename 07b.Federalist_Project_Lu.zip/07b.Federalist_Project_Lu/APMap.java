import java.util.*;
 
public interface APMap{

	public boolean containsKey(Object key);

	public Object get(Object key);

	public Object put(Object key, Object val);

	public Set keySet();

	public int size();

	public Object remove(Object key);

}